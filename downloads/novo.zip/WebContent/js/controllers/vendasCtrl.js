angular.module("vendas").controller("vendasCtrl",function($scope) {
    $scope.app = "vendas";
});