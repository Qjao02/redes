angular.module("vendas").config(function ($routeProvider) {
    $routeProvider.when("/categoria", {
        templateUrl: 'view/categoriaView.html',
        controller: "vendasCtrl"
    });
});